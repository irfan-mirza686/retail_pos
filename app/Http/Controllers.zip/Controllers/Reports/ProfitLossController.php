<?php

namespace App\Http\Controllers\Reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;
use Auth;
use App\Models\Purchase,App\Models\PurchasePayment;
use App\Models\Expense;
use App\Models\Sale,App\Models\SalePaymentDetail;
use App\Models\AdvanceCustomerPayment;
use App\Models\ReceivablePayable;

class ProfitLossController extends Controller
{
    /*==============================================================================*/
    public function profitLoss(Request $request)
    {
        Session::put('page','profitLoss');
        /*Fetch Total Amount of Purchase*/
        $data['getTotalPurchaseAmount'] = PurchasePayment::where('payment_status','received')->sum('total_amount');
        /*Fetch Total Paid Amount of Purchase*/
        $data['getTotalPurchasePaidAmount'] = PurchasePayment::where('payment_status','received')->sum('paid_amount');
        /*Fet Total Due Amount of Purchase*/
        $data['getTotalPurchaseDueAmount'] = PurchasePayment::where('payment_status','received')->sum('due_amount');

        $customerAmount = AdvanceCustomerPayment::sum('amount');
        $prePayable = ReceivablePayable::where('type','payable')->sum('amount');
        $data['salePaidAmount'] = $customerAmount + $prePayable;
        // dd($salePaidAmount);
        /*Fetch Expenses*/
        $data['expenses'] = Expense::sum('amount');

        /*Fetch Total Amount of Sales*/
        $data['getTotalSalesAmount'] = Sale::where('status',1)->sum('amount');
        /*Fetch Total Paid Amount of Sales*/
        $data['salesDiscount'] = Sale::where('status',1)->sum('discount');
        

        

        $getItemsTotalAmount = 0;
        $returnItemsTotalAmount = 0;

        $getCalculatedCostAmount = 0;
        $returnCalculatedCostAmount = 0;

        $grossProfit = 0;
        $returnGrossProfit = 0;

        /*Fetch Calculations of Sales*/
        $getSales = Sale::where('status',1)->get()->toArray();
        // echo "<pre>"; print_r($getSales); exit();

        
        foreach ($getSales as $key => $value) {
        //     $customerSale = $value['pos_sale'];
    
        // foreach ($customerSale as $key => $value) {
            
            /*Fetch Calculated Cost & Items Total for Gross Profit*/
            $product_addons = unserialize($value['items_addon']);
            
            foreach ($product_addons as $key => $addons) {
                $calculatedCost = $addons['calculatedCost'];
                $itemsTotal = $addons['amount'];
                $quantity = $addons['quantity'];
                $getCalculatedCostAmount = $calculatedCost + $getCalculatedCostAmount;
                $getItemsTotalAmount = $itemsTotal + $getItemsTotalAmount;

                $grossProfit = $getItemsTotalAmount - $getCalculatedCostAmount;
                $totalGrossProfit = $grossProfit;

            }
        }
        // }
        
        /*Calculate Gross Profit*/
        $returnGrossProfit = $totalGrossProfit - $data['salesDiscount'];
      

        /*Calculate Net Profit*/
        $dataCashOut = $data['getTotalPurchasePaidAmount'] + $data['expenses'];
        
        $netProfit = (float)$data['getTotalSalesAmount'] - (float)$dataCashOut;
        // dd($netProfit);
        /*Fetch Items wise Profit*/
        $data['products'] = Sale::where('status',1)->get()->toArray();
        // echo "<pre>"; print_r($data['products'][0]['items_addon']); exit();
        

        return view('reports.profit_loss.index',$data,compact('returnGrossProfit','netProfit'));
    }
    /*==============================================================================*/
}
