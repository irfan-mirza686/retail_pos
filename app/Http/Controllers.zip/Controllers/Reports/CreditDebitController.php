<?php

namespace App\Http\Controllers\Reports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;
use Auth;
use PDF;
use App\Models\Customer;
use App\Models\Sale;
use App\Models\AdvanceCustomerPayment;
use App\Models\CustomerOpeningBalance;
use App\Models\Area;
class CreditDebitController extends Controller
{
    /*=======================================================*/
    public function index()
    {
            Session::put('page','creditDebitReport');
            $customers = Customer::get();
            $areas = Area::get();
            return view('reports.credit_debit_report.create',compact('customers','areas'));
    }
    /*=======================================================*/
   public function compare_date($element1, $element2) {
               
                $datetime1 = strtotime($element1['date']);
                $datetime2 = strtotime($element2['date']);
                return $datetime1 - $datetime2;
            } 
    public function creditDebitReport(Request $request)
    {
        if ($request->isMethod('post')) {

            $data = $request->all();
            // echo "<pre>"; print_r($data); exit();
            $startDate = date('Y-m-d',strtotime($data['startDate']));
            $endDate = date('Y-m-d',strtotime($data['endDate']));
            $area = '';
            $area_id = '';
            $sale_type = $data['sale_type'];
            $receivable = '';
            $payable = '';
            $customerBalance = '';
            $paymentDiscount = '';
            $customer = '';
            $debitCredit = '';
            $openingBalance = '';
         
            // echo "<pre>"; print_r($data); exit();
            if ($data['sale_type']=='areaWise') {
                $area_id = $data['area_id'];
                $area = Area::where('id',$data['area_id'])->first();

                
            }else{
                $openingBalance = CustomerOpeningBalance::select('date','description','amount')->where('customer_id',$request->customer_id)->first();


               $totalAmount = Sale::select('voucher_no','date','description','amount')->whereBetween('date',[$startDate,$endDate])->where('customer_id',$request->customer_id)->where('status',1)->get()->toArray();
               $arrSaleDebit = [];
               foreach ($totalAmount as $key => $value) {
                 $arrSaleDebit[] = [
                    'voucher_no' => "SN-".($value['voucher_no']),
                    'date' => $value['date'],
                    'description' => $value['description'],
                    'credit' => '',
                    'debit' => $value['amount']
                ];
            }
               // echo "<pre>"; print_r($totalAmount); exit();
               $totalPayable = CustomerOpeningBalance::select('voucher_no','date','description','amount')->whereBetween('date',[$startDate,$endDate])->where('customer_id',$request->customer_id)->where('type','debit')->get()->toArray();
               // $debitAmount = array_merge($totalPayable, $totalAmount);
               
               $arrDebitBalance = [];
               foreach ($totalPayable as $key => $value) {
                 $arrDebitBalance[] = [
                    'voucher_no' => "VCH-".($value['voucher_no']),
                    'date' => $value['date'],
                    'description' => $value['description'],
                    'credit' => '',
                    'debit' => $value['amount']
                ];
            }
           

               $totalAdvance = AdvanceCustomerPayment::select('voucher_no','date','description','amount')->whereBetween('date',[$startDate,$endDate])->where('customer_id',$request->customer_id)->get()->toArray();
                // echo "<pre>"; print_r($totalAdvance); exit();
               $arrCustomerPaymentCredit = [];
               foreach ($totalAdvance as $key => $value) {
                 $arrCustomerPaymentCredit[] = [
                    'voucher_no' => "CP-".($value['voucher_no']),
                    'date' => $value['date'],
                    'description' => $value['description'],
                    'credit' => $value['amount'],
                    'debit' => ''
                ];
            }
              
               $totalReceivable = CustomerOpeningBalance::select('voucher_no','date','description','amount')->whereBetween('date',[$startDate,$endDate])->where('customer_id',$request->customer_id)->where('type','credit')->get()->toArray();
               // $creditAmount = array_merge($totalReceivable, $totalAdvance);
               
               $arrCreditBalance = [];
               foreach ($totalReceivable as $key => $value) {
                 $arrCreditBalance[] = [
                    'voucher_no' => "VCH-".($value['voucher_no']),
                    'date' => $value['date'],
                    'description' => $value['description'],
                    'credit' => $value['amount'],
                    'debit' => ''
                ];
            }
            
            $debitCredit = array_merge($arrDebitBalance,$arrCreditBalance,$arrCustomerPaymentCredit,$arrSaleDebit);
            // echo "<pre>"; print_r($debitCredit); exit();

                        // Comparison function
              

            // Sort the array 
             // usort($debitCredit,function() {});
             // usort(array($this, 'compareDates'));
            // usort($debitCredit, array($this, "compare_date"));
            usort($debitCredit, array("App\Http\Controllers\Reports\CreditDebitController", 'compare_date'));
            
               $paymentDiscount = AdvanceCustomerPayment::where('customer_id',$request->customer_id)->sum('payment_discount');
              
               
               $customerBalance = ($this->totalAmount($request->customer_id) + $this->customerDebitAmount($request->customer_id)) - ($this->paymentDicsount($request->customer_id) + $this->advanceAmount($request->customer_id) + $this->customerCreditAmount($request->customer_id));
            
               $customer = Customer::where('id',$request->customer_id)->first(); 
           }
           $sale_type = $data['sale_type'];
           $pdf = PDF::loadView('reports.pdf.credit_debit.report',compact('startDate','endDate','debitCredit','openingBalance','area_id','area','sale_type','customerBalance','customer','paymentDiscount'));
           return $pdf->stream('credit-debit-report.pdf');
       }
   }
    /*=======================================================*/
}
