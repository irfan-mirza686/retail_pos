@if(!isset($print_footer) )
<footer class="main-footer">
    <strong>Copyright &copy; 2012 - <?php print_r( date('Y') ); ?> <!-- <a href="https://outseller.net" target="_blank">OutSeller Group</a>. --></strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <!-- <b>FoodEngine<sup>TM</sup></b> v 4.0 -->
    </div>
  </footer>
  @endif